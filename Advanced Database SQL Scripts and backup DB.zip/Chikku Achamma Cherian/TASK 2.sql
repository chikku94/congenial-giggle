--Database Creation
CREATE DATABASE PrescriptionsDB;
USE PrescriptionsDB;

-- Create the Medical_Practice table
CREATE TABLE Medical_Practice (
    PRACTICE_CODE NVARCHAR(50) NOT NULL PRIMARY KEY,
    PRACTICE_NAME NVARCHAR(50) NOT NULL,
    ADDRESS_1 NVARCHAR(50) NOT NULL,
    ADDRESS_2 NVARCHAR(50),
    ADDRESS_3 NVARCHAR(50),
    ADDRESS_4 NVARCHAR(50),
    POSTCODE NVARCHAR(50)NOT NULL
);

-- Create the Drugs table
CREATE TABLE Drugs (
    BNF_CODE NVARCHAR(50) NOT NULL PRIMARY KEY,
    CHEMICAL_SUBSTANCE_BNF_DESCR NVARCHAR(100) NOT NULL,
    BNF_DESCRIPTION NVARCHAR(100) NOT NULL,
    BNF_CHAPTER_PLUS_CODE NVARCHAR(100)NOT NULL
);

  
-- Create the Prescriptions table
CREATE TABLE Prescriptions (
    PRESCRIPTION_CODE INT PRIMARY KEY NOT NULL,
    PRACTICE_CODE NVARCHAR(50) NOT NULL,
    BNF_CODE NVARCHAR(50)NOT NULL,
    QUANTITY FLOAT NOT NULL,
    ITEMS SMALLINT NOT NULL,
    ACTUAL_COST MONEY NOT NULL,
    FOREIGN KEY (PRACTICE_CODE) REFERENCES Medical_Practice (PRACTICE_CODE),
    FOREIGN KEY (BNF_CODE) REFERENCES Drugs (BNF_CODE)
);


--Query 2 Returns details of all drugs which are in the form of tablets or capsules.
SELECT * FROM Drugs WHERE BNF_DESCRIPTION LIKE '%tablets%' OR BNF_DESCRIPTION LIKE '%capsules%';


--Query 3 Returns the total quantity for each of prescriptions
SELECT PRESCRIPTION_CODE, ROUND(QUANTITY * ITEMS, 0) AS Total_Quantity FROM Prescriptions;


--Query 4 Returns a list of the distinct chemical substances which appear in the Drugs table
SELECT DISTINCT CHEMICAL_SUBSTANCE_BNF_DESCR FROM Drugs ORDER BY CHEMICAL_SUBSTANCE_BNF_DESCR


--Query 5  Returns the number of prescriptions,Average and the Minimum and Maximum prescription costs

SELECT BNF_CHAPTER_PLUS_CODE, count(*) as NumberofPrescriptions, ROUND(AVG(ACTUAL_COST),2) as Average_Cost,
ROUND(MAX(ACTUAL_COST),2) as Maximum_Cost,  ROUND(MIN(ACTUAL_COST),2) as Minimum_Cost
FROM Drugs
INNER JOIN Prescriptions ON
Drugs.BNF_CODE=Prescriptions.BNF_CODE
GROUP BY BNF_CHAPTER_PLUS_CODE


--Query 6 Returns the most expensive prescription by each practice and is more than �4000.
SELECT Medical_Practice.PRACTICE_CODE, PRACTICE_NAME, ACTUAL_COST as PRESCRIPTION_COST FROM Medical_Practice
INNER JOIN Prescriptions ON
Medical_Practice.PRACTICE_CODE=Prescriptions.PRACTICE_CODE
WHERE ACTUAL_COST>4000 ORDER BY ACTUAL_COST DESC


--Query 7 Nested Queries 
--Query 1: Use of JOIN and GROUP BY clause to fetch the Practice Code and Practice name of the Practice who prescribed at least one prescription.
SELECT mp.PRACTICE_CODE , mp.PRACTICE_NAME  FROM Medical_Practice mp
WHERE EXISTS (SELECT * FROM Prescriptions p WHERE
              mp.PRACTICE_CODE=p.PRACTICE_CODE);

--Query 2: Use of Joins and GROUP BY clause To fetch the total prescriptions and total cost
SELECT p.PRACTICE_CODE, mp.PRACTICE_NAME, COUNT(p.PRESCRIPTION_CODE) as total_prescriptions, SUM(p.ACTUAL_COST) as total_cost
FROM Prescriptions p
JOIN Medical_Practice mp ON p.PRACTICE_CODE = mp.PRACTICE_CODE
GROUP BY p.PRACTICE_CODE, mp.PRACTICE_NAME

--Query 3: Use of SYSTEM FUNCTIONS to Query for the average and standard deviation of Actual Cost
SELECT AVG(ACTUAL_COST) as AverageCost, stdev(ACTUAL_COST) as StandardDeviationCost FROM Prescriptions


/*Query 4: Use of EXISTS clause and ORDER BY clause to find out to find
chemical substances  that have prescribed prescriptions for all drugs in the Drugs table*/

SELECT CHEMICAL_SUBSTANCE_BNF_DESCR, BNF_DESCRIPTION, BNF_CHAPTER_PLUS_CODE
FROM Drugs d
WHERE EXISTS (SELECT 1 FROM Prescriptions p WHERE p.BNF_CODE = d.BNF_CODE)
ORDER BY CHEMICAL_SUBSTANCE_BNF_DESCR ASC


--Query 5: Use of GROUP BY clause and nested subquery
SELECT mp.PRACTICE_NAME, COUNT(p.PRESCRIPTION_CODE) as total_prescriptions, 
(SELECT AVG(ACTUAL_COST) FROM Prescriptions WHERE PRACTICE_CODE = p.PRACTICE_CODE) as avg_cost
FROM Prescriptions p
JOIN Medical_Practice mp ON p.PRACTICE_CODE = mp.PRACTICE_CODE
GROUP BY mp.PRACTICE_NAME, p.PRACTICE_CODE
HAVING COUNT(p.PRESCRIPTION_CODE) > 500
