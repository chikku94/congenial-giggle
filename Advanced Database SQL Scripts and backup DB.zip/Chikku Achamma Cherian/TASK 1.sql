create database LibraryDB;

use LibraryDB;


--Creation of Tables required
CREATE TABLE member_details (
    member_id INT not null  PRIMARY KEY,
    full_name VARCHAR(max) not null,
    address VARCHAR(MAX) not null,
    dob DATE ,
    username VARCHAR(50) not null,
    password VARCHAR(15) not null,
    email VARCHAR(50) NULL,
    telephone_no VARCHAR(13) NULL
);

CREATE TABLE fine_info (
    fine_id INT PRIMARY KEY NOT NULL,
    member_id INT,
    total_overdue_fine FLOAT,
    amount_repaid FLOAT,
	payment_method VARCHAR(10),
    outstanding_balance AS (total_overdue_fine - amount_repaid),
    date_of_repayment DATE,
    membership_end_date DATE,
    FOREIGN KEY (member_id) REFERENCES member_details(member_id)
);

CREATE TABLE catalogue (
    item_id INT PRIMARY KEY NOT NULL,
    item_title VARCHAR(55),
    author VARCHAR(30),
	item_type varchar(20),
	removal_date date,
	ISBN varchar(20),
    year_of_publication DATE,
    item_added_date DATE,
    current_status VARCHAR(10)
);


-- Create a scalar-valued function to calculate the day of delay
CREATE FUNCTION dbo.GetDayOfDelay
(
    @date_returned DATE,
    @date_due DATE,
    @today DATE
)
RETURNS INT
AS
BEGIN
    DECLARE @days_due INT;
    IF @date_due IS NOT NULL
        SET @days_due = DATEDIFF(DAY, @date_due,@date_returned);
    ELSE
        SET @days_due = DATEDIFF(DAY, @date_returned, @today);
    
    RETURN @days_due;
END;

CREATE TABLE loan(
    loan_id INT PRIMARY KEY,
    member_id INT NOT NULL,
    item_id INT NOT NULL,
    date_taken DATE,
    date_returned DATE,
    date_due DATE,
    today DATE DEFAULT GETDATE(),
    days_due AS (dbo.GetDayOfDelay(date_returned, date_due, today)),
    overdue_fee AS (dbo.GetDayOfDelay(date_returned, date_due, today) * 10),
    FOREIGN KEY (member_id) REFERENCES member_details(member_id),
    FOREIGN KEY (item_id) REFERENCES catalogue(item_id)
);

--Query 6
---Insert Data into member_details Table

INSERT INTO member_details (member_id, full_name, address, dob, username, password, email, telephone_no)
VALUES (1, 'John Doe', '1234 Main St', '1990-01-01', 'johndoe', 'myp@ssword', 'johndoe@example.com', '123-456-7890'),
(2, 'Jane Smith', '5678 Elm St', '1985-03-15', 'janesmith', 'mypassw0rd', 'janes@example.com', '987-654-3210'),
(3, 'Michael Johnson', '7890 Oak St', '1978-09-10', 'michael', '123password', 'michael@example.com', '456-789-1230'),
(4, 'Sarah Thompson', '4567 Maple Ave', '1995-06-25', 'sarah', '345password', 'sarahth@example.com', '789-123-4560');


Select * from member_details;

-- Insert Data into the fine_info table
INSERT INTO fine_info(fine_id, total_overdue_fine, amount_repaid, date_of_repayment, membership_end_date, member_id, payment_method)
VALUES 
   
    (1, 180, 70, '2022-07-01', '2022-08-01', 1, 'cash'),
    (2, 200, 90, '2022-08-01', '2022-09-01', 4, 'card'),
    (3, 150, 60, '2022-09-01', '2022-10-01', 2, 'cash'),
    (4, 220, 80, '2022-10-01', '2022-11-01', 3, 'card');


select * from fine_info;


-- Insert Data into the catalogue table

INSERT INTO catalogue (item_id, item_title, author, item_type, year_of_publication, item_added_date, current_status,removal_date,ISBN)
VALUES 
(1,'The Great Gatsby', 'F. Scott Fitzgerald', 'Book', '1925-04-10', '2022-12-04', 'Available', NULL, '800-8-16-148410-0'),
(2,'1984', 'George Orwell', 'Book', '1949-06-08', '2021-04-01', 'Overdue', NULL, '822-8-16-148410-0'),
(3,'The Shawshank Redemption', 'Frank Darabont', 'Book', '1994-09-23', '2022-05-02', 'Available', NULL, '675-8-16-148410-0'),
(4,'The Mona Lisa', 'Leonardo da Vinci', 'Other Media', '1503-08-21', '2018-05-02', 'removed', '2022-03-18', '895-8-16-198410-0'),
(5,'Abstract Art: Exploring the Unknown', 'Wassily Kandinsky', 'DVD', '1910-12-02', '2023-05-04', 'Available', NULL, '978-3-16-148410-0'),
(6,'Science Fiction Literature', 'Arthur C. Clarke', 'journal', '1965-07-14', '2022-03-21', 'Overdue', NULL, '699-8-17-148410-0');

Select * from catalogue


--- Insert Data into the loan table

INSERT INTO loan (loan_id, member_id, item_id, date_taken, date_returned, date_due)
VALUES

    (1, 2, 2, '2022-03-08', '2023-03-20', '2023-03-08'),
    (2, 3, 3, '2022-02-06', NULL, '2023-04-19'),
	(3, 1, 1, '2023-02-04', NULL, '2023-04-20'),
    (4, 4, 5, '2022-03-12','2022-03-20' , '2022-03-18');
    
	Select * from loan
	
--Query 2
-- Create the stored procedure
CREATE PROCEDURE SearchCatalogueByTitle
    @Title VARCHAR(100)
AS
BEGIN
    -- a) Search the catalogue for matching character strings by title.*/

    SELECT *FROM catalogue WHERE item_title LIKE '%' + @Title + '%' ORDER BY year_of_publication DESC;
END

EXEC SearchCatalogueByTitle @Title = 'The Mona Lisa';


--2.b)  Return a full list of all items currently on loan which have a due date of less than five days from the current date 
CREATE PROCEDURE GetItemsDueSoon
AS
BEGIN

	SELECT loan.item_iD, catalogue.item_title, loan.date_due, DATEDIFF(day, loan.date_due, getdate()) as days_due  FROM     
      loan
      INNER JOIN catalogue ON loan.item_id=catalogue.item_id
	  INNER JOIN member_details ON loan.member_id= member_details.member_id
	WHERE date_returned IS NULL 
    AND DATEDIFF(day, loan.date_due, getdate()) < 5
END

EXEC GetItemsDueSoon;


--2. c) Create a stored procedure named InsertMember
CREATE PROCEDURE InsertMember
	@member_id INT ,
	@full_name VARCHAR(MAX),
    @address VARCHAR(MAX),
	@dob DATE,
	@username VARCHAR(50),
    @password VARCHAR(15),
    @email VARCHAR(50) = NULL,
    @telephone_no VARCHAR(13) = NULL
AS
BEGIN
    -- Insert the new member into member_details table
    INSERT INTO member_details (member_id,full_name, address,dob,username, password, email, telephone_no)
    VALUES (@member_id,@full_name, @address, @dob, @username, @password,@email, @telephone_no);
END

-- Example usage of the InsertMember stored procedure with different input values
EXEC InsertMember  '5','Pritha Manna', '789 Oak St, New York, USA','1998-04-01','Pritha', '120password',
'prithamanna@example.com', '8765432109';

select * from member_details;


--2.d) Create the UpdateMemberDetails stored procedure
CREATE PROCEDURE UpdateMemberDetails
    @member_id INT,
    @full_name VARCHAR(MAX),
    @address VARCHAR(MAX),
    @dob DATE,
    @username VARCHAR(50),
    @password VARCHAR(15),
    @email VARCHAR(50),
    @telephone_no VARCHAR(13)
AS
BEGIN
    -- Update the member details
    UPDATE member_details
    SET full_name = @full_name,
        address = @address,
        dob = @dob,
        username = @username,
        password = @password,
        email = @email,
        telephone_no = @telephone_no
    WHERE member_id = @member_id;
END;

-- Example usage of the UpdateMemberDetails stored procedure
EXEC UpdateMemberDetails
    @member_id = 4,  
    @full_name = 'Deepa Saha',  
    @address = '456 Elm St, Anytown, USA',  
    @dob = '1995-05-15',  
    @username = 'Dipas', 
    @password = 'newpassword',  
    @email = 'Dipaa@example.com',  
    @telephone_no = '9876543210'; 

--Query 3. Create View for Loan History 

CREATE VIEW LoanHistory AS
	SELECT member_id, loan.item_id , catalogue.item_title, catalogue.item_type, date_taken, date_returned, 
	date_due, days_due, days_due*0.10  AS fine
	FROM loan
	INNER JOIN catalogue ON
	catalogue.item_id=loan.item_id 
GO
SELECT * FROM LoanHistory

--Query 4 Trigger for current status updates to Overdue when the book is Not returned by due or Available if returned

CREATE TRIGGER update_catalogue_status
ON loan
AFTER INSERT, UPDATE
AS
BEGIN
    DECLARE @item_id INT;
    DECLARE @status VARCHAR(10);

    SELECT @item_id = item_id FROM inserted;

    IF EXISTS (SELECT * FROM loan WHERE item_id = @item_id AND date_returned IS NULL)
    BEGIN
        SET @status = 'Overdue';
    END
    ELSE
    BEGIN
        SET @status = 'Available';
    END

    UPDATE catalogue SET current_status = 'Overdue' WHERE item_id ='1'
END;
select * from catalogue;

--Query 5 Function to get total number of loans made on a specified date
CREATE FUNCTION GetTotalLoansByDate
(
    @loanDate DATE
)
RETURNS INT
AS
BEGIN
    DECLARE @totalLoans INT;
    
    SELECT @totalLoans = COUNT(*)
    FROM loan
    WHERE CONVERT(DATE, date_taken) = @loanDate;
    
    RETURN @totalLoans;
END;


-- Example usage of the GetTotalLoansByDate function
DECLARE @totalLoans INT;
SET @totalLoans = dbo.GetTotalLoansByDate('2022-03-08'); -- Replace '2022-03-08' with the actual date for which you want to get the total number of loans
PRINT 'Total loans on specified date: ' + CAST(@totalLoans AS VARCHAR(10));



