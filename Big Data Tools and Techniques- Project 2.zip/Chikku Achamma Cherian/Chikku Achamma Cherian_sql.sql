-- Databricks notebook source
-- MAGIC %python
-- MAGIC
-- MAGIC # Load the Clinical CSV file into a DataFrame
-- MAGIC Clinicaltrial_2021_df = spark.read.format("csv").option("header", "true").option("delimiter", ",").load("dbfs:/FileStore/tables/clinicaltrial_2021.csv")
-- MAGIC Clinicaltrial_2021_df.createOrReplaceTempView('clinicaltrial_2021')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC # Rename the columns
-- MAGIC Clinicaltrial_2021_df = Clinicaltrial_2021_df.withColumnRenamed("id","Id") \
-- MAGIC        .withColumnRenamed("sponsor","Sponsor") \
-- MAGIC        .withColumnRenamed("status","Status") \
-- MAGIC        .withColumnRenamed("start_date","Start") \
-- MAGIC        .withColumnRenamed("completion_date","Completion") \
-- MAGIC        .withColumnRenamed("type","Type") \
-- MAGIC        .withColumnRenamed("submission_date","Submission") \
-- MAGIC        .withColumnRenamed("conditions","Conditions") \
-- MAGIC        .withColumnRenamed("interventions","Interventions")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC Clinicaltrial_2021_df = Clinicaltrial_2021_df.dropna(how="all", thresh=None, subset=None)

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- Create Clinicaltrial_2021 table
-- MAGIC CREATE TABLE Clinicaltrial_2021_SQL (
-- MAGIC   Id STRING,
-- MAGIC   Sponsor STRING,
-- MAGIC   Status STRING,
-- MAGIC   Start DATE,
-- MAGIC   Completion DATE,
-- MAGIC   Type STRING,
-- MAGIC   Submission DATE,
-- MAGIC   Conditions STRING,
-- MAGIC   Interventions STRING
-- MAGIC )
-- MAGIC USING csv
-- MAGIC OPTIONS (
-- MAGIC   header "true",
-- MAGIC   path "/FileStore/tables/clinicaltrial_2021.csv"
-- MAGIC );
-- MAGIC  
-- MAGIC  
-- MAGIC  

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- Create pharma table
-- MAGIC CREATE TABLE Pharma_SQL (
-- MAGIC   Violation STRING,
-- MAGIC   Parent_Company STRING
-- MAGIC )
-- MAGIC USING csv
-- MAGIC OPTIONS (
-- MAGIC   header "true",
-- MAGIC   path "/FileStore/tables/pharma.csv"
-- MAGIC );

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC --Q1 Display number of distinct studies in the dataset.
-- MAGIC SELECT COUNT(DISTINCT Id) AS number_studies FROM Clinicaltrial_2021_SQL;
-- MAGIC  

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- Q2 Types of studies in the dataset along with the frequencies of each type.
-- MAGIC  
-- MAGIC  
-- MAGIC     SELECT Type, COUNT(*) as count
-- MAGIC     FROM Clinicaltrial_2021_SQL
-- MAGIC     GROUP BY Type 
-- MAGIC     ORDER BY count DESC;
-- MAGIC  
-- MAGIC  

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC
-- MAGIC --#Q3 Top 5 conditions (from Conditions) with their frequencies.
-- MAGIC
-- MAGIC SELECT Conditions, COUNT(*) AS Frequency
-- MAGIC FROM Clinicaltrial_2021_SQL
-- MAGIC WHERE Conditions IS NOT NULL
-- MAGIC GROUP BY Conditions
-- MAGIC ORDER BY Frequency DESC
-- MAGIC LIMIT 5
-- MAGIC  

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC  
-- MAGIC -- #Q4 10 most common sponsors that are not pharmaceutical companies, along with the number of clinical trials they have sponsored.
-- MAGIC
-- MAGIC SELECT c.Sponsor, COUNT(DISTINCT c.Id) AS clinical_trials
-- MAGIC FROM Clinicaltrial_2021_SQL c
-- MAGIC LEFT JOIN Pharma_SQL p ON c.Sponsor = p.Parent_Company
-- MAGIC WHERE p.Parent_Company
-- MAGIC  IS NULL
-- MAGIC GROUP BY c.Sponsor
-- MAGIC ORDER BY clinical_trials DESC
-- MAGIC LIMIT 10
-- MAGIC  

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- #Q4  Number of completed studies each month in 2021
-- MAGIC
-- MAGIC SELECT DATE_FORMAT(TO_DATE(Completion, 'MMM yyyy'), 'MM') AS MONTH, COUNT(*) AS count
-- MAGIC FROM Clinicaltrial_2021_SQL
-- MAGIC WHERE Status = 'Completed' AND Completion IS NOT NULL
-- MAGIC GROUP BY MONTH
-- MAGIC ORDER BY MONTH

-- COMMAND ----------


