install.packages('e1071', dependencies=TRUE)
install.packages('forecast')
library(forecast)
library(e1071)
# 4.1
#Mean for numerical variable
colMeans(data[sapply(data, is.numeric)])

# Median
Trade.median <- median(data$Trade..USD.)
print(Trade.median)

Quantity.median <- median(data$Quantity)
print(Quantity.median)

Weight.median <- median(data$Weight..kg.)
print(Weight.median)

#mode1
my_mode <- function(x) {                    
  unique_x <- unique(x)
  tabulate_x <- tabulate(match(x, unique_x))
  unique_x[tabulate_x == max(tabulate_x)]
}
x1 <- c(data$Trade..USD.)  
my_mode(x1)  

#mode2
my_mode2 <- function(x) {                    
  unique_x <- unique(x)
  tabulate_x <- tabulate(match(x, unique_x))
  unique_x[tabulate_x == max(tabulate_x)]
}
x2 <- c(data$Weight..kg.)
my_mode2(x2)

#mode3
my_mode3 <- function(x) {                    
  unique_x <- unique(x)
  tabulate_x <- tabulate(match(x, unique_x))
  unique_x[tabulate_x == max(tabulate_x)]
}
x3 <- c(data$Quantity)
my_mode2(x3)

#Standard devition
sd (data$Trade..USD.)
sd(data$Weight..kg.)
sd(data$Quantity)

#Skewness
skewness(data$Trade..USD.,type=2)
skewness(data$Weight..kg.,type=2)
skewness(data$Quantity,type=2)

#Kurtosis
kurtosis(data$Trade..USD.,type=2)
kurtosis(data$Quantity,type=2)
kurtosis(data$Weight..kg.,type=2)

#4.2
#Correlation between indicators
print(cor(data[ c('Year','Trade..USD.','Weight..kg.','Quantity')]))

#4.3
# linear Regression
l_reg <-lm(data$Trade..USD.~data$Quantity)
print(l_reg)
#Printing the summary of our Linear Regression Analysis
print(summary(l_reg))

#4.4
#Time Series Analysis
value <- c(data$Trade..USD.)
value.timeseries <- ts(value,start=c(2010,1),frequency = 12)
print(value.timeseries)
plot(value.timeseries,main='Before prediction')
model<-auto.arima(value.timeseries)
model
#Making predictions for 10 forecasted years
forecast_data<-forecast(model,10)
print(forecast_data)
plot(forecast_data,main= "The data predictions for next 10 years for value.timeseries")
#4.5
#Anova test
oneway <- aov(Year ~ Trade..USD., data = data)
summary(oneway)

#t-test
t.test(data$Year,data$Trade..USD.)


#5       
#Dropping null values
data <- na.omit(`Silk Trade`)
data

#Detecting Outliers for Trade column
hist(data$Trade..USD.,
     xlab = "trade-USD",
     main = "Histogram of trade",
     breaks = sqrt(nrow(data))
) 

# For Weight column
hist(data$Weight..kg.,
     xlab = "Weight",
     main = "Histogram of Weight-kg",
     breaks = sqrt(nrow(data))
) 
#For quantity column
hist(data$Quantity,
     xlab = "Quantity",
     main = "Histogram of Quantity",
     breaks = sqrt(nrow(data))
) 

getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

# Create the vector with numbers.
v <- c(data$Trade..USD.)

# Calculate the mode using the user function.
result <- getmode(v)
print(result)

